# ROADMAP — 开发路线图

| 项 | 值 |
|---|---|
| 状态 | Draft v0.1（规划阶段，未进入实现） |
| 更新日期 | 2026-09-28 |
| 依据 | 制作流程第 10 步；项目规则「增量开发 / 测试必选 / 不擅自扩大范围」 |
| 关联文档 | GAME_DESIGN.md / DATABASE_SPEC.md / SIMULATION_SPEC.md / SAVE_SPEC.md |

---

> **决策更新（2026-09-28，第 14 步）**：部分 TBD 已裁决（详见 `DECISIONS.md`）。
> **R3** 稳定目标 = **50 赛季基础压力测试，保留更高赛季测试能力**（A8）。
> 其余 `[TBD]` 仍然有效。

## 0. 文档定位与边界

本文件回答一个问题：**先做什么，后做什么。**

- 本文件定义：五个阶段的**目标、范围、交付物、依赖关系、验收口径**。
- 本文件**不**重复各系统的设计细节（见对应 SPEC 文档）。
- 核心红线：
  - **不为了"看起来完整"而增加功能。**
  - 显著影响架构 / 数据结构 / 存档兼容 / 模拟的设计，**先标 TBD 并请制定者决策**。
  - 每阶段结束时系统必须**可测试**，不只"在 UI 里能跑一次"。
  - 不擅自引入多人在线 / 变现 / 3D / 社交 / 云账号等未获批准内容。

### 标记约定

- `[已定]` / `[TBD]` / `[建议]` 同前。

### 通用流程（每阶段内部）`[已定]`

1. 设计 → 2. 定数据结构 → 3. 实现核心逻辑 → 4. 写测试 → 5. 测边界 → 6. 接 UI → 7. 再测 → 8. 更新文档。

---

## 1. 第一阶段：最小可玩版本（MVP）

**目标**：验证"数据 → 世界 → 比赛 → 结果"这条最小闭环能跑通，且架构分层正确。

- 范围（候选，**需与制定者确认后再细化**）：
  - 引擎骨架与分层边界（核心逻辑 / 数据层 / UI 分离）`[已定原则]`。
  - 最小数据库加载（单一 `.fdb`，最少实体）。
  - 最小比赛模拟（已定 A2：时段制）。
  - 单联赛赛程、积分、单赛季推进。
  - 极简 UI：能看到球队、球员、赛程、结果。
  - 最小存档：能存/读当前日期与比赛结果。
- 依赖：`SIMULATION_SPEC` T6 已定（A2 时段制）；仍需决策 `DATABASE_SPEC` 实体最小集、`GAME_DESIGN` T1。
- 交付物：可运行的第一代客户端原型 + 对应单元测试 + 文档更新。
- 验收：同一（库+档+种子）比赛结果可复现；存读一致；无魔法数字散落。

### 1.1 已交付（2026-09-29，MVP 第一切片）

- 暂定范围（DECISIONS D-09）：**仅比赛闭环**，不含转会/合同/财政。
- 已实现：赛程生成、四维球队实力、时段制单场模拟、积分榜、单赛季推进与赛季滚动（归档上季积分榜）、存读一致。
- 已交付测试：RNG 确定性、赛程正确性（含奇数队轮空）、实力梯度、单场可复现、积分守恒、整赛季、多赛季滚动、存档往返、数据校验、比分分布校准护栏（共 46 项全通过）。
- 已交付数据：`data/worlds/mvp-league.fdb`（单联赛 8 队双循环，球员带属性），引擎不依赖该具体库。
- 已交付 UI：积分榜、上赛季最终排名、最近赛果、推进一天/一周、保存/读取。
- **比分分布（D-12）**：大样本实测场均总进球 ≈2.79，已在现实区间 → **S12 口径已定、无需调参**。
- `[TBD]` 待制定者覆盖：D-09/D-10/D-11/D-12 为**暂定默认值**。

---

## 2. 第二阶段：核心系统

**目标**：把 GAME_DESIGN 认定的"四个核心"中的基础部分立起来。

- 范围（候选）：
  - 球员成长（训练、比赛经验、年龄、职业素养…）→ 能力变化。
  - 转会（"需求+意愿+合同+身价+工资+声望+竞争+经纪人 → 谈判"的简化版）。
  - 合同（薪资、年限、到期、续约）。
  - 财政基础（收支与约束，防崩防通胀）。
  - 战术系统（T5 最小集合）。
  - 教练与工作人员（视 T11 决策）。
- 依赖：第一阶段架构与存档机制稳定后再扩展；数据结构变更需带迁移（`SAVE_SPEC` §5）。
- 交付物：核心系统模块 + 单元/集成测试。
- 验收：单赛季内核心系统闭环；存档跨版本仍可读写。
- `[TBD]` R2：四个核心（比赛/成长/转会/世界）在本阶段的完成度目标。

### 2.1 已交付（2026-09-29，第 15 步：球员运行时状态）

- 目标：在静态球员库之上建立**独立的 Player Runtime State**，为后续成长/伤病/合同/转会/战术**预留接口**。
- 已实现：`src/core/player-runtime.js`——创建/读取/修改接口；`getEffectiveAttributes`（完整属性向量，非单一总评）；
  `recordAppearance`（本赛季+职业生涯统计）、`setVitals`、`applyInjury/recoverInjury`、`applyAbilityDelta`、
  `resetSeasonStats`；`createGameState` 为全部球员建状态；赛季滚动重置本赛季统计；读档自动补齐（保留已有值）。
- **刻意未做**：成长算法、伤病生成/恢复算法、体能/状态/士气更新模型（均属 `[TBD]`，S2–S11/S13）。
- 已交付测试：`tests/player-runtime.test.js` 19 项（创建/读取/修改/存读往返/静态库冻结不变/向后兼容）。
  累计 **65/65 通过**。
- `[TBD]` 字段级口径（D-13 暂定）待制定者确认；`GAME_STATE_SCHEMA_VERSION` 1→2（加法式，向后兼容）。

### 2.2 已交付（2026-09-29，第 16 步：球员成长 / 衰退）

- 目标：按赛季结算的能力成长与年龄衰退，与比赛、年龄、潜力、伤病、状态/士气、人格兼容（D-14）。
- 已实现：`src/core/player-growth.js`；静态库新增 `birthDate/potential(每属性上限)/personality` 并**定为必填**；
  两个仓库内测试库已补齐；`simulation.js` 赛季滚动时先结算成长再重置赛季统计；`GAME_STATE_SCHEMA_VERSION` 2→3（加法式）。
- **刻意未做**：训练系统本体（仅预留修正接口）、退役/新生代/青训。
- 已交付测试：`tests/growth.test.js` 18 项；累计 **83/83 通过**。
- 长期护栏：真实库 50 赛季属性均值 51.6 → 9.0 **单调不升**；10/50/100 赛季无越界/NaN（D1/D2）。

### 2.3 已交付（2026-09-29，第 17 步：伤病生命周期）

- 目标：完善**伤病生命周期**（发生 → 每日递减 → 自动恢复 → vitals），并修复第 16 步的成长惩罚耦合问题（D-15）。
- 已实现：`src/core/player-injury.js`（赛后最小伤病判定、每日推进、vitals）；`sim-config.js` `INJURY_CONFIG`（8 类型、3 严重度，配置驱动）；
  `player-runtime.js` 扩展 `injury` 结构与定长 `injuryHistory`；`player-growth.js` **只消费** `growth.injuryPenaltySeasons`（不再自行推断）；
  `team-strength.js`/`simulation.js` 过滤伤病球员（空阵容保护）；`GAME_STATE_SCHEMA_VERSION` 3→4（加法式，向后兼容）。
- **刻意未做**：完整训练系统、首发/换人、青年队补位、紧急转会、医疗团队/设施、复杂康复、比赛内伤病事件链、无限伤病历史。
- 已交付测试：`tests/injury.test.js` 21 项（含整季 / 50 / 100 赛季压力）；累计 **104/104 通过**。

### 2.4 已交付（2026-09-29，第 18 步：赛季级球员生态联调）

- 目标：**打通已有系统闭环**（不新增玩法系统）——修复第 16/17 步审计发现的三处断点（D-16）。
- 已实现：`team-strength.js` 改用**有效属性**并新增 `selectMatchSquad`（出场集合，单一可替换点）；
  `simulation.js#playFixture` 接入出场/进球统计与赛后 fitness/form；`sim-config.js` 新增 `MATCH_LOAD_CONFIG`；
  健康体能改为**分数式**恢复。`GAME_STATE_SCHEMA_VERSION` **保持 4**（纯接线）。
- **刻意未做**：首发/替补/换人、训练本体、青年队、紧急转会、退役/新生代。
- 已交付测试：`tests/ecosystem.test.js` 16 项（含 10/50/100 赛季）；累计 **120/120 通过** + 浏览器冒烟通过。
- **已知范围**：无退役/新生代 → 长期世界均值与球队实力随老龄化单调回落（属既有成长/衰退规则）；退役 + 新生代 + 人口生态平衡保留为后续独立步骤。

### 2.5 已交付（2026-09-29，第 19 步：退役 + 新生代 + 世界人口生态平衡）

- 目标：为世界建立"退出/进入"通道，消除长期（50–100 赛季）世界均值坍缩（D-17）。
- 已实现：`src/core/player-lifecycle.js`（退役：年龄软区间线性概率 + 硬上限；新生代：同位置静态模板+三路独立抖动；人口补位）；
  `player-runtime.js` 新增**统一世界球员访问器**并把 4 模块 9 处直读 `static.players` 迁移；`game-state.js` 新增
  `generated/retired/nextGeneratedSeq/populationTarget` 且 `GAME_STATE_SCHEMA_VERSION` 4→5（加法式）。
- **刻意未做**：自由球员池、转会、合同、青训梯队、预备队、名人堂 UI、财政、教练、多联赛、完整伤病史、历史裁剪。
- 已交付测试：`tests/lifecycle.test.js` 19 项（含 10/50/100/200 赛季）；累计 **139/139 通过** + 浏览器冒烟通过。
- **长期护栏（实测 1/10/50/100/200 季）**：总人口恒 112、GK 恒 8、无重复 ID、均值不坍缩不膨胀、退役≈新生。

### 2.6 已交付（2026-09-29，第 20 步：玩家阵容 / 战术选择）

- 目标：建立「玩家管理球队 → 比赛 → 结果反馈」的**最小可玩闭环**（D-18）。
- 已实现：`src/core/player-lineup.js`（阵容槽位/校验/清洗/比赛修复/赛季自愈）；`team-strength.js` 新增
  `resolveMatchSquad`（玩家阵容 vs 自动选阵统一入口）、`buildAutoLineup`，`computeTeamStrength` 接收实际出场集合；
  `simulation.js#buildSide` 使用统一入口、赛季滚动调用 `repairManagedLineups`；`game-state.js` 新增
  `managedClubId`（默认 null）与 `clubs[].lineup`、`initializeClubRuntime`，`GAME_STATE_SCHEMA_VERSION` 5→6（加法式）；
  `game-controller.js` 新增阵容/战术 API 与快照；`app-view.js` + `main.css` 新增「我的球队」卡片。
- **刻意未做（out-of-scope）**：转会、合同、财政、工资、身价、球探、教练、青训、预备队、AI 转会市场、多联赛、
  升降级、杯赛、红黄牌、**换人引擎**、大规模比赛表现系统、名人堂、新闻系统。
- 已交付测试：`tests/lineup.test.js` 22 项（含 save/load、阵型/战术真实影响比赛、10/50 赛季）；累计 **159/159 通过** + 浏览器冒烟通过。

### 2.7 已交付（2026-09-29，G0：运行期成员关系层）

- 目标：把 player→club / club→league 从"主要依赖静态字段"升级为**统一、可变、可持久化的运行期唯一真相源**（D-19）。
  不新增玩法，仅为后续财政/转会/合同/AI/升降级/赛事扩展提供唯一基础。
- 已实现：`src/core/membership.js`（叶子模块）；`player-runtime.js` 访问器改经 membership（`getTeamPlayers`/`getPlayerProfile`
  归属、`computePopulationTarget`）；`game-state.js` 建世界时初始化 membership、`getTeamsByLeague` 经 membership；
  `player-lifecycle.js` 新生代入队 + 退役出队；`save-manager.js` 兜底；`game-controller.js` 读档校验 + 快照；
  `GAME_STATE_SCHEMA_VERSION` **6→7**（加法式）。
- **刻意未做（out-of-scope）**：转会、合同、自由球员、财政、工资、身价、AI 转会、升降级、多联赛、杯赛。
- 已交付测试：`tests/membership.test.js` 19 项（含 v6→v7 迁移、唯一真相源、顺序契约、10/50/100/200 赛季）；累计 **178/178 通过** + 浏览器冒烟通过。

### 2.8 已交付（2026-09-29，G1a：比赛球员参与结构）

- 目标：把"谁在 squadIds 里 = 出场 90 分钟"的隐式模型升级为统一的 `MatchResult.involvements`（D-20）。
  不新增玩法，不实现换人/评分/射门/控球/传球。
- 已实现：`match.js` 事件统一为 `actorId/assistId` + `buildInvolvements`；`simulation.js#applyPostMatch` 只消费 involvements；
  `player-runtime.js` 统计线新增 `yellow/red`，`recordAppearance` 消费 `minutes/goals/assists/yellow/red`；
  `GAME_STATE_SCHEMA_VERSION` **7→8**（加法式，唯一原因：统计线新增持久化 `yellow/red`）。
- **刻意未做（out-of-scope）**：换人/替补上场、临场战术、球员评分、射门/控球/传球、AI、转会、合同、财政、杯赛、多联赛、G1b。
- 已交付测试：`tests/involvement.test.js` 12 项（含黄金路径、确定性、save/load continuation）；累计 **190/190 通过** + 浏览器冒烟通过。

### 2.9 已交付（2026-09-29，G1b①：赛季日历 + 赛季边界驱动）

- 目标：把"某 competition `finished` → 推进 `state.season` → 执行全局副作用"的**隐式**约定，升级为显式的
  「SeasonCalendar + 赛季边界」模型；**单联赛下行为与改造前完全等价**（D-21）。仅改变"赛季边界的判断方式"与 rollover 编排。
- 已实现：新增叶子模块 `src/core/season.js`（`getSeasonCalendar` / `isSeasonBoundaryReached`，派生视图、不入档、无随机）；
  `simulation.js#rollFinishedSeasons` 改为**由边界驱动**（边界到达才归档/建新季/执行一次副作用；`advanceDay` 外部顺序不变）。
- **兼容红线**：`state.season` 字段名与持久化保留（单联赛 `state.season ≡ comp.season ≡ calendar.season`）；
  `SEASON_GAP_DAYS=30`、赛程轮转、fixture 日期、`deriveMatchSeed` 的 season 输入、growth/lifecycle RNG 全部不变。
- **存档**：`GAME_STATE_SCHEMA_VERSION` **保持 8**（派生视图，不新增持久化字段，无需迁移）。
- **刻意未做（out-of-scope，属 G1b②）**：多联赛、多 competition 并行、杯赛、淘汰赛、升降级、Competition Rules 数据化、
  多竞赛统一赛季边界、competition type dispatch、新 schedule 类型。
- 已交付测试：`tests/season.test.js` 11 项（SeasonCalendar 投影、边界 < / = / > / 空联赛、改造前基线指纹行为等价、
  副作用一次性与顺序、确定性、save/load 季中/边界前/边界日/新赛季后、10/50/100 赛季长期）；累计 **201/201 通过** + 浏览器冒烟通过。

### 2.10 已交付（2026-09-29，Step 21-A：球员比赛表现 MVP）

- 目标：在 G1a 统一 `involvements` 之上补齐**球员级比赛表现**（射门/射正/助攻/牌/评分），支撑赛后表现反馈与统计（D-22）。
- 已实现：`match.js#applyMatchPerformance`（**独立派生 RNG**，比分确定后生成，逐球员/逐进球独立流）；
  `sim-config.js` `MATCH_PERFORMANCE_CONFIG`（位置射门画像、助攻概率、牌概率、评分模型）；
  `player-runtime.js` 统计线新增 `shots/shotsOnTarget/ratingSum` 并支持 `recordAppearance` 消费；
  `simulation.js#applyPostMatch` 仅透传（不新增并行写入链）；`game-state.js` `GAME_STATE_SCHEMA_VERSION` **8→9**（加法式）。
- **红线（已证明）**：`rng.js`/`deriveMatchSeed`/比分算法**未改**；相同 seed 下 `homeGoals/awayGoals/goal events` 与实施前**逐值一致**；
  表现**不写回** form/morale/fitness/growth/retirement；守恒内建 `shots>=shotsOnTarget>=goals`、`Σassists<=Σgoals`。
- **刻意未做（out-of-scope）**：keyPasses、xG、possession、pass%、比赛报告、Man of the Match、UI 展示、
  表现影响 form/morale/growth/retirement、换人/替补、新能力属性/能力体系；转会/合同/工资/财务/AI 教练/多联赛/杯赛/升降级。
- 已交付测试：`tests/performance.test.js` 11 项（单场确定性、比分/射门守恒、助攻合法性、cards 有界、rating 边界与累计、
  season/career 累计与 reset、save/load 含 schema 8→9 与旧档补 0、RNG 隔离黄金指纹、10/50/100 赛季长期）；累计 **212/212 通过** + 浏览器冒烟通过。

### 2.11 已交付（2026-09-29，Step 21-B：球员表现数据消费层）

- 目标：把 21-A 已持久化的球员 `season/career` 表现接入 **controller 快照 → UI**（**仅消费层，方案 A**，D-23）。
- 已实现：`player-runtime.getPlayerStatsView`/`deriveAverageRating`（只读派生视图，安全规范化，返回新对象）；
  `game-controller#managedClubView` 球员条目新增 `stats`；`app-view` 新增紧凑可换行的**赛季统计行**；`styles/main.css` 适配。
- **展示**：管理球队阵容每名球员展示 `出场/进球/助攻/射门/射正/评分`（黄/红为次级）；`评分 = ratingSum/appearances/10`，
  无出场显示 `—`（无 NaN）；`ratingSum` **不外泄**，UI 不自行计算。
- **红线**：schema **保持 9**（无迁移）；无 match history / 逐场持久化 / 排行榜 / 球员详情页；UI 不直读 state；
  21-A 模型 / RNG / 评分公式 / 比分 / standings / 统计产生逻辑**均未改动**。
- 已交付测试：`tests/consumption.test.js` 10 项（season/career 读取、averageRating 与 `appearances=0`、ratingSum 不外泄、
  `shots>=shotsOnTarget`、旧字段 normalize、快照与 runtime 无引用共享、非管理球队不展示、lineup/injury 不受影响）；累计 **222/222 通过** + 浏览器冒烟通过。

### 2.12 设计冻结（2026-09-29，Step 23：Contract / Finance / Transfer 语义地基）

- **性质**：**纯设计冻结，无代码 / 无 schema / 无数据 / 无测试变更**（schema 仍为 **9**）。决策编号 **D1–D20**，详见
  [DECISIONS D-24](file:///workspace/docs/DECISIONS.md) 与 [SIMULATION_SPEC](file:///workspace/docs/SIMULATION_SPEC.md) §30。
- **已冻结 `[已定]`（D1–D9、D11–D20）**：membership 为唯一业务真相；`runtime.contracts[playerId]`（单 active、整数赛季、每赛季工资、不自动续约）；
  允许 active free agent（**不得**形成三套并列真相）；`club.finance={cash,wageBudget,transferBudget}`（**仅 cash 为余额**）；
  俱乐部阵容上下限；确定性转会费模板；转会窗口永久开放；退役清合同；schema 9→10 迁移方案；
  **v1 工资不从 cash 扣除**；统一 domain operation 层；AI 复用同一 domain ops；**人口政策与世界/俱乐部保护分离**（废弃精确恢复 112）；
  读档不变量校验；**不新增随机源**。
- **仍待定 `[TBD]`（D10）**：生成球员的合同语义（入队+初始合同 / 先自由身 / 模板继承），须与青年队 / 自由球员市场 / AI 转会一并决定。
- **下一步（未开始）**：Contract + minimal Finance → Transfer → AI Management（依赖 [SIMULATION_SPEC](file:///workspace/docs/SIMULATION_SPEC.md) §30）。

### 2.13 已交付（2026-09-29，Step 25：合同 / 财政地基）

- **目标**：按 Step 23 冻结的 D1–D20 落地 **Contract Foundation + Finance Foundation**（Transfer / Free Agent 生效 / Population 政策均**不含在内**）。
- **已实现**：新增 [contract.js](file:///workspace/src/core/contract.js)（`runtime.contracts[playerId]`、accessor、`createContract`/`terminateContract`、
  `normalizeContracts`、`assertContractInvariants`）与 [finance.js](file:///workspace/src/core/finance.js)（`clubs[].finance`、`getSpendableCash`、
  `normalizeFinance`、`assertFinanceInvariants`）；`game-state.js` 归一化+校验；`game-controller#load` 读档补齐+断言；
  `player-lifecycle#archiveRetired` 保存最终合同快照并终止合同；`sim-config.js` 新增 `CONTRACT_CONFIG`/`FINANCE_CONFIG`。
- **schema**：`GAME_STATE_SCHEMA_VERSION` **9→10**（加法式）；旧档经确定性 normalize 补齐；`SAVE_FORMAT_VERSION` 未改。
- **确定性**：合同/财政全为确定性模板（**无新增随机源**）；整季比赛黄金指纹（143/143/1141）不变。
- **明确未做**：Transfer、Free Agent **运行时生命周期**、release、roster bounds、Population 政策（D16）、工资现金扣除、
  生成球员合同最终语义（**D10 仍 TBD**）、AI、UI。
- 已交付测试：`tests/foundation.test.js` 16 项（合同/财政/迁移/不变量/确定性/长期）；累计 **238/238 通过** + 浏览器冒烟通过。

---

## 3. 第三阶段：完整足球世界

**目标**：让"没有玩家的球队也自己活着"，并保证长期稳定。

- 范围（候选）：
  - AI 球队决策（买卖、换帅、改战术、财政、青训提拔）→ 世界自主演化。
  - 青训系统与新生代生成；球员退役与衰退。
  - 新闻与事件（可解释的信息输出）。
  - 杯赛、多层级 / 多国联赛（视 T7 决策）。
  - 多赛季世界模拟与稳定性收敛。
- 依赖：`SIMULATION_SPEC` §14、§15 的模型决策（T12、T14）；**Contract / Finance / Transfer 语义地基见 §30（D-24，Step 23 冻结）**。
- **下一实施阶段（未开始）**：`Contract + minimal Finance → Transfer → AI Management`；其中 **D10（生成球员合同语义）须先确认**，
  且须遵循 D7/D16 的「世界人口健康边界 ⊥ 俱乐部阵容上下限」分离策略。
- 交付物：世界模拟引擎 + 长期模拟测试。
- 验收（项目规则第 17 条）：跨 1 / 5 / 10 / 50 赛季稳定（保留 100+ 能力）；无空阵容、无不可能年龄、无指数通胀、无腐坏。
- `[已定]` R3（A8）：稳定时长 = **50 赛季基础，保留更高**；世界规模仍待定（见 T7）。

---

## 4. 第四阶段：数据库 / Mod 系统

**目标**：让社区 / 玩家能提供与替换足球世界内容。

- 范围（候选）：
  - 完整 `.fdb` 规范落地（版本化、校验、诊断）。
  - 数据库导入 / 切换流程与存档兼容策略（`SAVE_SPEC` T-S/V10）。
  - 数据库校验与错误诊断工具。
  - Mod 支持形态（视 T17 决策）。
- 依赖：`DATABASE_SPEC` 全部 TBD 决策落定。
- 交付物：数据库工具链 + 文档。
- 验收：至少两个不同数据库可被同一引擎加载；换库不破坏既有存档。
- `[TBD]` R4：Mod 支持的正式形态与边界（资源版权见 `DATABASE_SPEC` §5 红线）。

---

## 5. 第五阶段：Android App 封装与发布

**目标**：把 HTML 客户端交付为可发布的 Android App（TapTap 方向）。

- 范围（候选）：
  - 封装方案选型（WebView 容器 / 混合方案等）`[TBD]` R5。
  - 移动端适配、性能与内存优化（项目规则第 20 条）。
  - 存档在移动端的存储与备份策略。
  - 打包、签名、发布准备。
- 依赖：前四阶段稳定；性能指标达标。
- 交付物：可安装的 Android 包 + 发布说明。
- 验收：目标机型可流畅运行；存档安全；无崩溃。
- `[TBD]` R5：封装技术方案；`[TBD]` R6：目标机型 / 性能基线（与 `GAME_DESIGN` 移动端定位绑定）。

---

## 6. 测试要求（贯穿全程）

依据项目规则第 18 条，随阶段推进**必须**覆盖：

- 数据库加载与校验
- 球员 / 球队创建
- 转会、合同
- 比赛模拟（含确定性复现）
- 联赛排程、积分、升降级
- 球员成长
- 存档 / 读档（含迁移与损坏档）
- 多赛季（1 / 5 / 10 / 50，并保留 100+ 测试能力）模拟

> 测试方案细节由 `testing-qa` Skill 在实现阶段补充；本文件只规定"必须标测试的节点"。

---

## 7. 阶段依赖总览

```
一阶段 MVP ──► 二阶段 核心系统 ──► 三阶段 完整世界 ──► 四阶段 数据库/Mod ──► 五阶段 Android 发布
     │                 │                   │                    │
   架构分层          存档迁移            AI/长期稳定性        .fdb 规范与换库
   + 最小闭环        数据扩展            版本兼容打磨         工具链
```

- 依赖红线：**不得**在架构 / 存档机制未稳定时大规模堆叠系统。
- 任一阶段的"重要设计影响项"必须先 TBD 决策再实现。

---

## 8. TBD 汇总（需制定者决策）

| 编号 | 位置 | 待决问题 | 影响面 |
|---|---|---|---|
| R1 | §1 | MVP 是否含转会/合同/财政 | 范围、工期 |
| R2 | §2 | 四大核心在本阶段的完成度目标 | 范围 |
| R3 ✅ | §3 | **已定（A8）**：50 赛季基础压力测试，保留更高 | — |
| R4 | §4 | Mod 支持正式形态 | 架构、版权 |
| R5 | §5 | Android 封装方案 | 技术栈、发布 |
| R6 | §5 | 目标机型与性能基线 | 性能、体验 |

---

## 9. 约束回顾（红线）

1. 不为了"看起来完整"而增加功能。
2. 影响架构 / 数据结构 / 存档兼容 / 模拟的设计先 TBD 决策。
3. 每阶段必须可测试，非"UI 能跑一次"。
4. 数据与逻辑分离；UI 与核心逻辑分离。
5. 不擅自扩大范围（无未批准的在线/变现/3D/社交等）。
6. **技术服务于设计**：不得为降低开发难度而擅自简化核心玩法；系统复杂时先提出简化方案供制定者选择，不得直接删除、弱化或替换核心设计。